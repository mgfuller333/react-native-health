# Units

The following units are supported by the library

```
  bpm
  calorie
  celsius
  count
  day
  fahrenheit
  foot
  gram
  hour
  inch
  joule
  meter
  mgPerdL
  mile
  minute
  mmhg
  mmolPerL
  percent
  pound
  second
  mlPerKgMin
```
